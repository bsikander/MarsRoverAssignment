package com.marsrover.cardinaldirection;

import com.marsrover.Point;

public class East extends CardinalDirection {
	
	public East() {
		super('E', 90, new Point(1,0));
	}
	
}
