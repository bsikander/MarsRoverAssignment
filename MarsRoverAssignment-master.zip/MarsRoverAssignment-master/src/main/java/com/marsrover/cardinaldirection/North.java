package com.marsrover.cardinaldirection;

import com.marsrover.Point;

public class North extends CardinalDirection {

	public North() {
		super('N', 0, new Point(0,1));
	}
	
}
