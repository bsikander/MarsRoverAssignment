package com.marsrover.cardinaldirection;

import com.marsrover.Point;

public class South extends CardinalDirection {
	
	public South() {
		super('S', 180, new Point(0,-1));
	}
	
}
