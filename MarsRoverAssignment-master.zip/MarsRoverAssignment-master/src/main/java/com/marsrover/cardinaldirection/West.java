package com.marsrover.cardinaldirection;

import com.marsrover.Point;

public class West extends CardinalDirection {
	
	public West() {
		super('W', 270, new Point(-1,0));
	}
	
}