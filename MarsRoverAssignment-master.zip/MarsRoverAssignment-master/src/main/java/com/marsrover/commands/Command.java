package com.marsrover.commands;

public interface Command {
	public boolean execute();
}
